// @ts-check
/**
 * Debate Orchestrator — automated multi-round debate between AI agents.
 *
 * Split into two layers per F-4 finding:
 * - DebateReducer: pure logic, returns action descriptors
 * - DebateExecutor: effectful, drives adapters and session mutations
 *
 * @module hub/debate-orchestrator
 */

import { getAdapter, hasAdapter } from '../adapters/adapter-registry.js';
import { groupFindings, mergeFindingsSmart } from './finding-aggregation.js';
import {
    isDebateTerminal,
    deriveNextDebateState,
} from './debate-state.js';
import { ConsensusEngine } from './consensus-engine.js';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFileSync } from 'node:child_process';

// ── Per-Agent Timeout Profiles ───────────────────────

/** @type {Readonly<Record<string, { reviewTimeoutMs: number, evalTimeoutMs: number, rebuttalTimeoutMs: number }>>} */
/** Both agents take 5-8 minutes for code reviews — generous identical timeouts */
export const DEBATE_AGENT_PROFILES = Object.freeze({
    codex: {
        reviewTimeoutMs: 360_000,
        evalTimeoutMs: 180_000,
        rebuttalTimeoutMs: 180_000,
    },
    'claude-code': {
        reviewTimeoutMs: 360_000,
        evalTimeoutMs: 180_000,
        rebuttalTimeoutMs: 360_000,
    },
});

/**
 * @typedef {'START_REVIEW' | 'START_CROSS_EVAL' | 'CHECK_CONSENSUS' | 'START_REBUTTAL' | 'TIE_BREAK' | 'RESOLVE' | 'FAIL'} ActionType
 *
 * @typedef {{
 *   type: ActionType,
 *   payload: Record<string, any>,
 * }} ActionDescriptor
 */

/**
 * @typedef {{
 *   dedupeKey: string,
 *   severity: string,
 *   title: string,
 *   agentId: string,
 *   file?: string,
 *   line?: number|null,
 *   evidence?: string|null,
 *   why_it_matters?: string|null,
 *   fix_instructions?: string|null,
 *   confidence?: number|null,
 *   round?: number,
 *   timestamp?: string,
 * }} FindingEntry
 *
 * @typedef {{
 *   dedupeKey: string,
 *   verdict: 'accepted' | 'rejected' | 'disputed',
 *   agentId: string,
 *   rationale?: string,
 *   round?: number,
 * }} EvaluationEntry
 */

/**
 * @param {import('../schema/events.js').Finding} finding
 * @param {string} agentId
 * @param {number} round
 * @returns {FindingEntry}
 */
function toFindingEntry(finding, agentId, round) {
    return {
        dedupeKey: finding.dedupe_key,
        severity: finding.severity,
        title: finding.summary,
        agentId,
        file: finding.file,
        line: finding.line ?? null,
        evidence: finding.evidence ?? null,
        why_it_matters: finding.why_it_matters ?? null,
        fix_instructions: finding.fix_instructions ?? null,
        confidence: finding.confidence ?? null,
        round,
        timestamp: new Date().toISOString(),
    };
}

/**
 * @param {Array<FindingEntry|import('../schema/events.js').Finding>} findings
 * @returns {string[]}
 */
function uniqueDedupeKeys(findings) {
    return [...new Set(findings.map((finding) => 'dedupeKey' in finding ? finding.dedupeKey : finding.dedupe_key))];
}

/**
 * @param {FindingEntry[]} disputed
 * @returns {string}
 */
function formatDisputedFindings(disputed) {
    if (disputed.length === 0) {
        return 'No disputed findings.';
    }

    const payload = disputed.map((finding) => ({
        dedupeKey: finding.dedupeKey,
        severity: finding.severity,
        title: finding.title,
        file: finding.file ?? 'unknown',
        line: finding.line ?? null,
        reported_by: finding.agentId,
        why_it_matters: finding.why_it_matters ?? '',
        fix_instructions: finding.fix_instructions ?? '',
        evidence: finding.evidence ?? '',
        confidence: finding.confidence ?? null,
    }));

    const bulletSummary = disputed.map((finding, index) => (
        `${index + 1}. [${finding.severity}] ${finding.title} (dedupeKey=${finding.dedupeKey})`
    )).join('\n');

    return [
        'Disputed findings JSON (exact items to adjudicate):',
        '```json',
        JSON.stringify(payload, null, 2),
        '```',
        '',
        'Quick disputed summary:',
        bulletSummary,
    ].join('\n');
}

/**
 * @param {import('./session.js').Session} session
 * @returns {'file_code'|'file_document'|'broad'}
 */
function getReviewScopeKind(session) {
    const filePath = resolveTargetFilePath(session);
    if (!filePath) {
        return 'broad';
    }

    const ext = path.extname(filePath).toLowerCase();
    if (['.md', '.txt', '.rst', '.adoc'].includes(ext)) {
        return 'file_document';
    }
    return 'file_code';
}

/**
 * @param {import('./session.js').Session} session
 * @returns {{ scopeKind: 'file_code'|'file_document'|'broad', resolutionPolicy: 'strict'|'soft_union', rebuttalBatchSize: number, clusterByTopic: boolean }}
 */
function getDebateStrategy(session) {
    const scopeKind = getReviewScopeKind(session);
    if (scopeKind === 'broad') {
        return {
            scopeKind,
            resolutionPolicy: 'soft_union',
            rebuttalBatchSize: 4,
            clusterByTopic: true,
        };
    }

    if (scopeKind === 'file_document') {
        return {
            scopeKind,
            resolutionPolicy: 'soft_union',
            rebuttalBatchSize: 4,
            clusterByTopic: true,
        };
    }

    return {
        scopeKind,
        resolutionPolicy: 'strict',
        rebuttalBatchSize: 6,
        clusterByTopic: true,
    };
}

/**
 * @param {FindingEntry} finding
 * @returns {string}
 */
function inferFindingTopic(finding) {
    const text = `${finding.title} ${finding.why_it_matters ?? ''} ${finding.fix_instructions ?? ''}`.toLowerCase();
    if (/\b(utf|encoding|unicode|decode|character)\b/.test(text)) return 'encoding';
    if (/\b(abort|close|error|hang|lifecycle|timeout|settle)\b/.test(text)) return 'lifecycle';
    if (/\b(memory|size|limit|oom|dos|payload)\b/.test(text)) return 'capacity';
    if (/\b(security|xss|injection|auth|permission)\b/.test(text)) return 'security';
    if (/\b(plan|spec|doc|document|requirements|contradiction)\b/.test(text)) return 'documentation';
    if (/\b(test|coverage|regression)\b/.test(text)) return 'testing';
    if (/\b(performance|latency|slow|backpressure)\b/.test(text)) return 'performance';
    return 'general';
}

/**
 * @param {FindingEntry[]} disputed
 * @param {import('./session.js').Session} session
 * @returns {Array<{ label: string, findings: FindingEntry[] }>}
 */
function buildDisputedBatches(disputed, session) {
    if (disputed.length === 0) {
        return [];
    }

    const strategy = getDebateStrategy(session);
    const maxBatchSize = strategy.rebuttalBatchSize;
    /** @type {Map<string, FindingEntry[]>} */
    const clusters = new Map();

    const ordered = [...disputed].sort((left, right) => {
        const fileCompare = String(left.file ?? '').localeCompare(String(right.file ?? ''));
        if (fileCompare !== 0) return fileCompare;
        const topicCompare = inferFindingTopic(left).localeCompare(inferFindingTopic(right));
        if (topicCompare !== 0) return topicCompare;
        const severityRank = { critical: 4, high: 3, medium: 2, low: 1 };
        return (severityRank[right.severity] ?? 0) - (severityRank[left.severity] ?? 0);
    });

    for (const finding of ordered) {
        const topic = strategy.clusterByTopic ? inferFindingTopic(finding) : 'general';
        const file = finding.file ?? 'unknown';
        const key = `${file}::${topic}`;
        const group = clusters.get(key) ?? [];
        group.push(finding);
        clusters.set(key, group);
    }

    /** @type {Array<{ label: string, findings: FindingEntry[] }>} */
    const batches = [];
    for (const [clusterKey, group] of clusters.entries()) {
        const [file, topic] = clusterKey.split('::');
        for (let index = 0; index < group.length; index += maxBatchSize) {
            const slice = group.slice(index, index + maxBatchSize);
            const batchNumber = Math.floor(index / maxBatchSize) + 1;
            const batchTotal = Math.ceil(group.length / maxBatchSize);
            batches.push({
                label: `${file} / ${topic} (${batchNumber}/${batchTotal})`,
                findings: slice,
            });
        }
    }

    return batches;
}

/**
 * @param {import('./session.js').Session} session
 * @returns {string[]}
 */
function buildScopeInstructions(session) {
    /** @type {string[]} */
    const instructions = [];
    const scopeKind = getReviewScopeKind(session);
    const reviewOptions = session.reviewOptions ?? {};
    const reviewTarget = typeof reviewOptions.review_target === 'string' ? reviewOptions.review_target : null;
    const filePath = typeof reviewOptions.file_path === 'string'
        ? reviewOptions.file_path
        : inferFilePathFromPrompt(session.prompt);

    if (reviewTarget === 'file' && filePath) {
        if (scopeKind === 'file_document') {
            instructions.push(`Primary review target: ${filePath}`);
            instructions.push('Base your review primarily on the inlined document or plan content below.');
            instructions.push('Review the document itself for contradictions, missing edge cases, unsafe guidance, and implementation risks.');
            instructions.push('Stay anchored to that file. Pull in other files only to verify a direct claim the document makes about existing code or behavior.');
            instructions.push('Do not drift into a general repository audit just because the target is a plan or document.');
            instructions.push(`Every finding must map back to ${filePath} or to a directly verified claim that materially changes the meaning of that document.`);
            return instructions;
        }
        instructions.push(`Primary review target: ${filePath}`);
        instructions.push('Base your review primarily on the inlined target file contents below.');
        instructions.push('The review sandbox may contain only the target file. If another dependency is unavailable, do not invent cross-file findings.');
        instructions.push('Stay anchored to that file. Inspect another file only to verify a concrete dependency, call site, or data flow that materially affects the target file.');
        instructions.push('Ignore any stale review outputs, handoff artifacts, debate transcripts, feedback inboxes, AGENTS instructions, skills, plans, spike reports, or unrelated tests unless the target file directly imports, executes, or depends on them.');
        instructions.push('Do not review the debate framework, prompts, or agent tooling unless the target file itself is part of that implementation.');
        instructions.push(`Every finding must map back to ${filePath} or to a directly verified interaction that changes its runtime behavior.`);
        return instructions;
    }

    instructions.push('Primary review scope: repository-wide or multi-file review.');
    instructions.push('Review the requested project or broad code scope directly.');
    instructions.push('Prefer the strongest issues that can be grounded in concrete files, modules, or interactions.');
    instructions.push('It is acceptable to inspect multiple related files when the issue depends on a cross-file interaction.');
    instructions.push('Do not drift into repository meta-artifacts, debate logs, AGENTS instructions, or git history unless the prompt explicitly asks for them.');
    return instructions;
}

/**
 * @param {string} prompt
 * @returns {string|null}
 */
function inferFilePathFromPrompt(prompt) {
    if (typeof prompt !== 'string' || prompt.length === 0) {
        return null;
    }
    const match = prompt.match(/([A-Za-z0-9_./\\-]+\.[A-Za-z0-9]+)/);
    return match ? match[1] : null;
}

/**
 * @param {import('./session.js').Session} session
 * @returns {string|null}
 */
function resolveTargetFilePath(session) {
    const reviewOptions = session.reviewOptions ?? {};
    const reviewTarget = typeof reviewOptions.review_target === 'string' ? reviewOptions.review_target : null;
    const filePath = typeof reviewOptions.file_path === 'string'
        ? reviewOptions.file_path
        : inferFilePathFromPrompt(session.prompt);

    if (reviewTarget === 'file' && filePath) {
        return filePath;
    }
    return null;
}

/**
 * @param {import('./session.js').Session} session
 * @returns {string[]}
 */
function buildTargetFileContext(session) {
    const filePath = resolveTargetFilePath(session);
    if (!filePath) {
        return [];
    }
    const scopeKind = getReviewScopeKind(session);

    const workspaceRoot = session.snapshotPath ?? session.projectDir;
    if (!workspaceRoot) {
        return [
            '',
            `Target file content (${filePath}) is unavailable in this test context.`,
        ];
    }
    const absolutePath = path.resolve(workspaceRoot, filePath);
    try {
        const raw = fs.readFileSync(absolutePath, 'utf8');
        const lines = raw.split('\n');
        const limit = scopeKind === 'file_document' ? 220 : 400;
        const truncated = lines.length > limit;
        const numbered = lines
            .slice(0, limit)
            .map((line, index) => `${index + 1}: ${line}`)
            .join('\n');

        return [
            '',
            `Target file content (${filePath}):`,
            '```text',
            numbered,
            '```',
            truncated
                ? `Note: truncated to first ${limit} lines${scopeKind === 'file_document' ? ' to keep document review focused and within prompt budget.' : '.'}`
                : 'End of target file.',
        ];
    } catch {
        return [
            '',
            `Target file content (${filePath}) could not be loaded from snapshot.`,
        ];
    }
}

/**
 * @param {import('./session.js').Session} session
 * @returns {string}
 */
function buildInitialReviewPrompt(session) {
    const scopeKind = getReviewScopeKind(session);
    const intro = scopeKind === 'file_document'
        ? 'You are performing an independent review of a document or implementation plan.'
        : scopeKind === 'broad'
            ? 'You are performing an independent broad-scope review across the requested project area.'
            : 'You are performing an independent code review pass.';
    const targetReminder = scopeKind === 'file_document'
        ? 'Review the target document itself, not the debate process around it.'
        : 'Review the target code itself, not the debate process around it.';
    return [
        intro,
        targetReminder,
        'Return only concrete, actionable findings using the normal review schema expected by your adapter.',
        scopeKind === 'broad'
            ? 'When the scope is broad, prioritize fewer, stronger findings over exhaustive lint-style enumeration.'
            : 'Keep the review tightly anchored to the requested scope.',
        ...buildScopeInstructions(session),
        ...buildTargetFileContext(session),
        '',
        'Original review prompt:',
        session.prompt,
    ].join('\n');
}

/**
 * @param {FindingEntry[]} disputed
 * @param {number} round
 * @param {import('./session.js').Session} session
 * @param {{ batchIndex?: number, batchCount?: number, batchLabel?: string }} [batchMeta]
 * @returns {string}
 */
function buildRebuttalPrompt(disputed, round, session, batchMeta = {}) {
    const scopeKind = getReviewScopeKind(session);
    return [
        `Debate round ${round}: re-review the same target scope and reconsider only the disputed findings listed below.`,
        'This is still a code review of the original target, not a review of debate artifacts or repository instructions.',
        batchMeta.batchCount && batchMeta.batchCount > 1
            ? `This rebuttal is batch ${batchMeta.batchIndex ?? 1} of ${batchMeta.batchCount}${batchMeta.batchLabel ? ` for cluster ${batchMeta.batchLabel}` : ''}. Focus only on this batch.`
            : 'Treat this as the full disputed set for the current round.',
        ...buildScopeInstructions(session),
        ...buildTargetFileContext(session),
        '',
        'Original review prompt:',
        session.prompt,
        '',
        'The disputed findings are already included below. Do not ask for them again.',
        'Treat the JSON block as the exact list of issues to adjudicate.',
        'Return only the issues you still believe are valid after reconsidering the code evidence.',
        'For each surviving issue, keep the same underlying issue as one of the disputed findings below and update the explanation if needed.',
        'For every surviving issue, copy the exact dedupeKey from the disputed item you are keeping.',
        'Return ONLY a JSON array of surviving issues. Do not include prose, verdict notes, or markdown before/after the array.',
        'If you now disagree with a disputed issue, omit it from your output.',
        scopeKind === 'broad'
            ? 'If a disputed item is generic, weak, or not grounded in the requested project scope, reject it by omitting it.'
            : 'If a disputed item is generic, ungrounded, or not actually about the target file, reject it by omitting it.',
        '',
        formatDisputedFindings(disputed),
    ].join('\n');
}

/**
 * @param {FindingEntry[]} disputed
 * @param {import('./session.js').Session} session
 * @param {{ batchIndex?: number, batchCount?: number, batchLabel?: string }} [batchMeta]
 * @returns {string}
 */
function buildTieBreakPrompt(disputed, session, batchMeta = {}) {
    return [
        'You are the tie-break reviewer for disputed findings.',
        'Re-review the original target scope and decide which disputed issues should survive final resolution.',
        'Do not audit debate artifacts, prompts, or repository instructions unless they are the review target.',
        batchMeta.batchCount && batchMeta.batchCount > 1
            ? `This tie-break is batch ${batchMeta.batchIndex ?? 1} of ${batchMeta.batchCount}${batchMeta.batchLabel ? ` for cluster ${batchMeta.batchLabel}` : ''}. Focus only on this batch.`
            : 'Treat this as the full disputed set for the current tie-break.',
        ...buildScopeInstructions(session),
        ...buildTargetFileContext(session),
        '',
        'Original review prompt:',
        session.prompt,
        '',
        'The disputed findings are already included below. Do not ask for them again.',
        'Treat the JSON block as the exact list of issues to adjudicate.',
        'For every surviving issue, copy the exact dedupeKey from the disputed item you are keeping.',
        'Return ONLY a JSON array of surviving issues. Do not include prose, verdict notes, or markdown before/after the array.',
        formatDisputedFindings(disputed),
    ].join('\n');
}

/**
 * @param {import('../schema/events.js').Finding[][]} findingGroups
 * @returns {import('../schema/events.js').Finding[]}
 */
function flattenFindings(findingGroups) {
    return findingGroups.flatMap((group) => group);
}

// ── DebateReducer (Pure) ─────────────────────────────

export class DebateReducer {
    /**
     * @param {{ maxRounds?: number, consensusThreshold?: number }} [options]
     */
    constructor(options = {}) {
        this.maxRounds = options.maxRounds ?? 3;
        this.consensusThreshold = options.consensusThreshold ?? 0.7;
        this.consensus = new ConsensusEngine({ threshold: this.consensusThreshold });
    }

    /**
     * @param {{
     *   debateState: string,
     *   debateRound: number,
     *   agents: string[],
     *   findings: FindingEntry[],
     *   evaluations: EvaluationEntry[],
     *   completedReviews: string[],
     *   completedEvals: string[],
     * }} context
     * @returns {ActionDescriptor}
     */
    getNextAction(context) {
        const { debateState, debateRound, agents, findings, evaluations, completedReviews, completedEvals } = context;

        switch (debateState) {
            case 'idle':
                return { type: 'START_REVIEW', payload: { agents } };

            case 'reviewing': {
                const allDone = agents.every((agent) => completedReviews.includes(agent));
                if (allDone) {
                    return { type: 'START_CROSS_EVAL', payload: { agents, findings } };
                }
                const pending = agents.filter((agent) => !completedReviews.includes(agent));
                return { type: 'START_REVIEW', payload: { agents: pending } };
            }

            case 'cross_eval': {
                const allDone = agents.every((agent) => completedEvals.includes(agent));
                if (allDone) {
                    return { type: 'CHECK_CONSENSUS', payload: { findings, evaluations } };
                }
                const pending = agents.filter((agent) => !completedEvals.includes(agent));
                return { type: 'START_CROSS_EVAL', payload: { agents: pending, findings } };
            }

            case 'consensus_check': {
                const agreement = this.consensus.calculateAgreement(findings, evaluations);
                if (this.consensus.hasConsensus(agreement.ratio, debateRound)) {
                    return { type: 'RESOLVE', payload: { agreement } };
                }
                if (debateRound >= this.maxRounds) {
                    return { type: 'TIE_BREAK', payload: { agreement } };
                }
                return { type: 'START_REBUTTAL', payload: { disputed: agreement.disputed } };
            }

            case 'debate_round':
                return { type: 'START_CROSS_EVAL', payload: { agents, findings } };

            case 'tie_break':
                return { type: 'RESOLVE', payload: { findings, evaluations, forceTieBreak: true } };

            case 'resolved':
            case 'failed':
                return { type: 'RESOLVE', payload: {} };

            default:
                return { type: 'FAIL', payload: { reason: `Unknown debate state: ${debateState}` } };
        }
    }

    /**
     * @param {ActionType} actionType
     * @param {{ success: boolean, [key: string]: any }} result
     * @returns {string}
     */
    getEventFromResult(actionType, result) {
        if (!result.success) return 'error';

        switch (actionType) {
            case 'START_REVIEW': return 'all_reviews_done';
            case 'START_CROSS_EVAL': return 'all_evals_done';
            case 'CHECK_CONSENSUS': return result.consensus ? 'consensus_reached' : (result.maxRoundsHit ? 'max_rounds' : 'no_consensus');
            case 'START_REBUTTAL': return 'rebuttals_done';
            case 'TIE_BREAK': return 'tie_broken';
            case 'RESOLVE': return 'consensus_reached';
            default: return 'error';
        }
    }
}

// ── DebateExecutor (Effectful) ───────────────────────

export class DebateExecutor {
    /**
     * @param {{
     *   session: import('./session.js').Session,
     *   adapterMap?: Record<string, any>,
     *   agentProfiles?: Record<string, { reviewTimeoutMs: number, evalTimeoutMs: number, rebuttalTimeoutMs: number }>,
     *   onSystemMessage?: (message: string) => void,
     *   onEvent?: (event: import('../schema/events.js').Event) => void,
     * }} options
     */
    constructor(options) {
        this.session = options.session;
        this.adapterMap = options.adapterMap ?? {};
        this.agentProfiles = options.agentProfiles ?? DEBATE_AGENT_PROFILES;
        this.onSystemMessage = options.onSystemMessage ?? (() => {});
        this.onEvent = options.onEvent ?? (() => {});
        this.reducer = new DebateReducer({
            maxRounds: this.session.debateMaxRounds ?? 3,
        });

        /** @type {FindingEntry[]} */
        this.findings = [];

        /** @type {EvaluationEntry[]} */
        this.evaluations = [];

        /** @type {string[]} */
        this.completedReviews = [];

        /** @type {string[]} */
        this.completedEvals = [];

        /** @type {Array<{ agentId: string, phase: string, startedAt: number, completedAt: number|null, timedOut: boolean }>} */
        this.timings = [];

        /** @type {Map<string, import('../schema/events.js').Finding[]>} */
        this.rawFindingsByAgent = new Map();

        /** @type {FindingEntry[]} */
        this.disputedFindings = [];

        /** @type {ReturnType<ConsensusEngine['calculateAgreement']>|null} */
        this.lastAgreement = null;

        /** @type {string|null} */
        this.executionWorkspace = null;
    }

    /**
     * @param {{ agents: string[], maxRounds?: number, decider?: string, consensusThreshold?: number }} config
     * @returns {{ debateState: string, round: number, agents: string[], maxRounds: number }}
     */
    initDebate(config) {
        const { agents, maxRounds = 3, decider, consensusThreshold = 0.7 } = config;

        if (!agents || agents.length === 0 || agents.length > 2) {
            throw new Error(`Debate requires 1-2 agents, got ${agents?.length ?? 0}`);
        }

        if (agents.length === 2 && !decider) {
            throw new Error('Decider is required for 2-agent debates');
        }

        // Warn if decider is also a debating agent (tie-break won't be independent)
        if (decider && agents.includes(decider)) {
            console.warn(`[Debate] Warning: decider "${decider}" is also a debating agent — tie-break will not be independent`);
        }

        this.session.debateState = 'idle';
        this.session.debateRound = 0;
        this.session.debateMaxRounds = maxRounds;
        this.session.debateAgents = [...agents];
        this.session.debateActive = true;
        this.session.debateRoundEvals = {};
        this.session.debateTimings = [];

        if (decider && this.session.assignments) {
            this.session.assignments.decider = decider;
        }

        this.reducer = new DebateReducer({
            maxRounds,
            consensusThreshold,
        });

        this.onSystemMessage(`Debate initialized: agents=[${agents.join(', ')}], maxRounds=${maxRounds}, decider=${decider ?? 'N/A'}`);

        return {
            debateState: 'idle',
            round: 0,
            agents: [...agents],
            maxRounds,
        };
    }

    /**
     * @param {string} event
     * @returns {{ state: string, valid: boolean }}
     */
    transition(event) {
        const current = this.session.debateState;
        const result = deriveNextDebateState(current, event);

        if (result.valid) {
            this.session.debateState = result.state;

            if (result.state === 'debate_round') {
                this.session.debateRound = (this.session.debateRound ?? 0) + 1;
            }

            if (isDebateTerminal(result.state)) {
                this.session.debateActive = false;
            }

            this.onSystemMessage(`Debate transition: ${current} → ${result.state} (event: ${event})`);
        }

        return result;
    }

    /**
     * @param {string} agentId
     * @param {string} phase
     * @param {number} startedAt
     * @param {number|null} completedAt
     * @param {boolean} timedOut
     */
    recordTiming(agentId, phase, startedAt, completedAt, timedOut) {
        const entry = { agentId, phase, startedAt, completedAt, timedOut };
        this.timings.push(entry);
        this.session.debateTimings = [...this.timings];

        if (completedAt) {
            const durationSec = Math.round((completedAt - startedAt) / 1000);
            this.onSystemMessage(`${agentId} ${phase} completed in ${durationSec}s${timedOut ? ' (TIMEOUT)' : ''}`);
        }
    }

    /**
     * @returns {{
     *   debateState: string|null,
     *   debateRound: number,
     *   debateMaxRounds: number,
     *   debateAgents: string[]|null,
     *   debateActive: boolean,
     *   findingsCount: number,
     *   evaluationsCount: number,
     * }}
     */
    getDebateStatus() {
        return {
            debateState: this.session.debateState ?? null,
            debateRound: this.session.debateRound ?? 0,
            debateMaxRounds: this.session.debateMaxRounds ?? 3,
            debateAgents: this.session.debateAgents ?? null,
            debateActive: this.session.debateActive ?? false,
            findingsCount: this.findings.length,
            evaluationsCount: this.evaluations.length,
        };
    }

    /**
     * @param {string} agentId
     * @returns {any}
     */
    resolveAdapter(agentId) {
        return this.adapterMap[agentId] ?? getAdapter(agentId);
    }

    /**
     * @returns {string}
     */
    getExecutionPath() {
        const targetFile = resolveTargetFilePath(this.session);
        const workspaceRoot = this.session.snapshotPath ?? this.session.projectDir;
        if (!targetFile || !workspaceRoot) {
            return this.session.snapshotPath ?? this.session.projectDir;
        }

        if (this.executionWorkspace) {
            return this.executionWorkspace;
        }

        const sourcePath = path.resolve(workspaceRoot, targetFile);
        const workspace = fs.mkdtempSync(path.join(os.tmpdir(), 'extension-debate-file-'));
        const sandboxFilePath = path.resolve(workspace, targetFile);
        fs.mkdirSync(path.dirname(sandboxFilePath), { recursive: true });
        fs.copyFileSync(sourcePath, sandboxFilePath);
        try {
            execFileSync('git', ['init', '-q'], { cwd: workspace, stdio: 'ignore' });
        } catch {
            // Best effort only; Codex trust config still helps when git is unavailable.
        }
        this.executionWorkspace = workspace;
        return workspace;
    }

    /**
     * @param {string} agentId
     * @param {'review'|'rebuttal'|'tie_break'} phase
     * @returns {{ firstByteMs: number, idleMs: number, hardMs: number }|undefined}
     */
    getPhaseTimeouts(agentId, phase) {
        const profile = this.agentProfiles[agentId];
        if (!profile) return undefined;

        const budgetMs = phase === 'review'
            ? profile.reviewTimeoutMs
            : phase === 'rebuttal'
                ? profile.rebuttalTimeoutMs
                : profile.evalTimeoutMs;

        return {
            firstByteMs: budgetMs,
            idleMs: budgetMs,
            hardMs: budgetMs,
        };
    }

    /**
     * @param {string[]} agentIds
     * @param {{ phase: 'review'|'rebuttal'|'tie_break', prompt: string, disputedKeys?: string[] }} options
     */
    async runReviewPass(agentIds, options) {
        const round = this.session.debateRound ?? 0;
        this.completedEvals = [];

        const results = await Promise.all(agentIds.map(async (agentId) => {
            const adapter = this.resolveAdapter(agentId);
            const startedAt = Date.now();
            const { stream, done } = adapter.execute(
                this.session.id,
                this.getExecutionPath(),
                options.prompt,
                { timeouts: this.getPhaseTimeouts(agentId, options.phase) },
            );

            for await (const event of stream) {
                this.onEvent(event);
            }

            const result = await done;
            const completedAt = Date.now();
            this.recordTiming(agentId, options.phase, startedAt, completedAt, result.status === 'timeout');

            if (result.status !== 'ok') {
                throw new Error(`${agentId} ${options.phase} failed with status "${result.status}"`);
            }

            return { agentId, findings: result.findings };
        }));

        for (const { agentId, findings } of results) {
            if (options.phase === 'rebuttal' && options.disputedKeys) {
                const retained = (this.rawFindingsByAgent.get(agentId) ?? [])
                    .filter((finding) => !options.disputedKeys.includes(finding.dedupe_key));
                const updated = findings.filter((finding) => options.disputedKeys.includes(finding.dedupe_key));
                this.rawFindingsByAgent.set(agentId, [...retained, ...updated]);
            } else {
                this.rawFindingsByAgent.set(agentId, findings);
            }

            this.completedReviews = [...new Set([...this.completedReviews, agentId])];
            this.onSystemMessage(`${agentId} produced ${(this.rawFindingsByAgent.get(agentId) ?? []).length} active findings in ${options.phase}.`);
        }

        this.rebuildFindingEntries();
    }

    /**
     * @param {string[]} agentIds
     * @param {'rebuttal'|'tie_break'} phase
     * @param {FindingEntry[]} disputed
     * @returns {Promise<void>}
     */
    async runClusteredReviewPass(agentIds, phase, disputed) {
        const batches = buildDisputedBatches(disputed, this.session);
        if (batches.length === 0) {
            return;
        }

        for (let index = 0; index < batches.length; index += 1) {
            const batch = batches[index];
            this.onSystemMessage(`Running ${phase} batch ${index + 1}/${batches.length}: ${batch.label} (${batch.findings.length} finding(s))`);
            await this.runReviewPass(agentIds, {
                phase,
                prompt: phase === 'rebuttal'
                    ? buildRebuttalPrompt(batch.findings, this.session.debateRound ?? 0, this.session, {
                        batchIndex: index + 1,
                        batchCount: batches.length,
                        batchLabel: batch.label,
                    })
                    : buildTieBreakPrompt(batch.findings, this.session, {
                        batchIndex: index + 1,
                        batchCount: batches.length,
                        batchLabel: batch.label,
                    }),
                disputedKeys: batch.findings.map((finding) => finding.dedupeKey),
            });
        }
    }

    rebuildFindingEntries() {
        const round = this.session.debateRound ?? 0;
        this.findings = [...this.rawFindingsByAgent.entries()]
            .flatMap(([agentId, findings]) => findings.map((finding) => toFindingEntry(finding, agentId, round)));
    }

    inferEvaluations() {
        const round = this.session.debateRound ?? 0;
        const agents = this.session.debateAgents ?? [];
        const currentByAgent = new Map(
            [...this.rawFindingsByAgent.entries()].map(([agentId, findings]) => [
                agentId,
                new Set(findings.map((finding) => finding.dedupe_key)),
            ]),
        );

        const dedupeKeys = uniqueDedupeKeys(this.findings);
        /** @type {EvaluationEntry[]} */
        const evaluations = [];

        for (const dedupeKey of dedupeKeys) {
            for (const agentId of agents) {
                const hasFinding = currentByAgent.get(agentId)?.has(dedupeKey) ?? false;
                evaluations.push({
                    dedupeKey,
                    verdict: hasFinding ? 'accepted' : 'rejected',
                    agentId,
                    round,
                    rationale: hasFinding
                        ? `Agent ${agentId} still reports this finding in round ${round}.`
                        : `Agent ${agentId} does not report this finding in round ${round}.`,
                });
            }
        }

        this.evaluations = evaluations;
        this.completedEvals = [...agents];
        this.session.debateRoundEvals[String(round)] = evaluations.reduce((acc, evaluation) => {
            const existing = acc[evaluation.dedupeKey] ?? [];
            existing.push(evaluation);
            acc[evaluation.dedupeKey] = existing;
            return acc;
        }, /** @type {Record<string, EvaluationEntry[]>} */ ({}));
    }

    /**
     * @param {FindingEntry[]} disputed
     */
    async runRebuttal(disputed) {
        this.disputedFindings = disputed;
        await this.runClusteredReviewPass(this.session.debateAgents ?? [], 'rebuttal', disputed);
    }

    /**
     * @returns {Promise<EvaluationEntry[]>}
     */
    async runTieBreakerIfNeeded() {
        const decider = this.session.assignments?.decider;
        if (!decider) {
            return [];
        }

        if ((this.session.debateAgents ?? []).includes(decider)) {
            return [];
        }

        if (!hasAdapter(decider) || this.disputedFindings.length === 0) {
            this.onSystemMessage(`Decider "${decider}" has no registered adapter. Falling back to confidence-based resolution.`);
            return [];
        }

        const adapter = this.resolveAdapter(decider);
        const batches = buildDisputedBatches(this.disputedFindings, this.session);
        /** @type {Set<string>} */
        const acceptedKeys = new Set();
        for (let index = 0; index < batches.length; index += 1) {
            const batch = batches[index];
            const startedAt = Date.now();
            const { stream, done } = adapter.execute(
                this.session.id,
                this.getExecutionPath(),
                buildTieBreakPrompt(batch.findings, this.session, {
                    batchIndex: index + 1,
                    batchCount: batches.length,
                    batchLabel: batch.label,
                }),
                { timeouts: this.getPhaseTimeouts(decider, 'tie_break') },
            );

            for await (const event of stream) {
                this.onEvent(event);
            }

            const result = await done;
            const completedAt = Date.now();
            this.recordTiming(decider, 'tie_break', startedAt, completedAt, result.status === 'timeout');

            if (result.status !== 'ok') {
                this.onSystemMessage(`Decider "${decider}" tie-break failed with status "${result.status}". Falling back to confidence-based resolution.`);
                return [];
            }

            for (const finding of result.findings) {
                acceptedKeys.add(finding.dedupe_key);
            }
        }

        return this.disputedFindings.map((finding) => ({
            dedupeKey: finding.dedupeKey,
            verdict: acceptedKeys.has(finding.dedupeKey) ? 'accepted' : 'rejected',
            agentId: decider,
            round: this.session.debateRound ?? 0,
            rationale: `Tie-break review by ${decider}`,
        }));
    }

    /**
     * @param {import('../schema/events.js').Finding[]} findings
     */
    applyResolvedFindings(findings) {
        /** @type {Map<string, string>} */
        const findingAgentMap = new Map();

        for (const [agentId, agentFindings] of this.rawFindingsByAgent.entries()) {
            for (const finding of agentFindings) {
                if (findings.some((entry) => entry.id === finding.id)) {
                    findingAgentMap.set(finding.id, agentId);
                }
            }
        }

        this.session.allFindings = findings;
        this.session.groupedFindings = groupFindings(findings, findingAgentMap);
        const mergeResult = mergeFindingsSmart(findings, findingAgentMap);
        this.session.mergedFindings = mergeResult.merged;
        this.session.mergeStats = mergeResult.stats;
    }

    async resolveFinalFindings() {
        const engine = new ConsensusEngine({ threshold: this.reducer.consensusThreshold });
        const strategy = getDebateStrategy(this.session);
        const tieBreakEvaluations = this.session.debateState === 'tie_break'
            ? await this.runTieBreakerIfNeeded()
            : [];
        const evaluations = [...this.evaluations, ...tieBreakEvaluations];
        const logical = engine.mergeFinalFindings(this.findings, evaluations, {
            decider: tieBreakEvaluations.length > 0 || (this.session.debateAgents ?? []).includes(this.session.assignments?.decider ?? '')
                ? this.session.assignments?.decider
                : undefined,
            policy: strategy.resolutionPolicy,
        });
        const keptKeys = new Set(logical.map((finding) => finding.dedupeKey));
        const finalFindings = flattenFindings([...this.rawFindingsByAgent.values()])
            .filter((finding) => keptKeys.has(finding.dedupe_key));

        this.applyResolvedFindings(finalFindings);
        this.onSystemMessage(`Debate resolved with ${logical.length} surviving finding(s).`);

        return {
            logicalFindings: logical,
            finalFindings,
            evaluations,
        };
    }

    /**
     * @param {{ agents: string[], maxRounds?: number, decider?: string, consensusThreshold?: number }} config
     */
    async run(config) {
        this.initDebate(config);
        this.transition('start');

        await this.runReviewPass(config.agents, {
            phase: 'review',
            prompt: buildInitialReviewPrompt(this.session),
        });

        this.transition('all_reviews_done');

        while (!isDebateTerminal(this.session.debateState ?? 'failed')) {
            const action = this.reducer.getNextAction({
                debateState: this.session.debateState ?? 'failed',
                debateRound: this.session.debateRound ?? 0,
                agents: this.session.debateAgents ?? [],
                findings: this.findings,
                evaluations: this.evaluations,
                completedReviews: this.completedReviews,
                completedEvals: this.completedEvals,
            });

            switch (action.type) {
                case 'START_CROSS_EVAL':
                    this.inferEvaluations();
                    this.transition('all_evals_done');
                    break;

                case 'CHECK_CONSENSUS': {
                    const agreement = this.reducer.consensus.calculateAgreement(this.findings, this.evaluations);
                    this.lastAgreement = agreement;
                    this.disputedFindings = agreement.disputed;
                    if (this.reducer.consensus.hasConsensus(agreement.ratio, this.session.debateRound ?? 0)) {
                        const resolution = await this.resolveFinalFindings();
                        this.transition('consensus_reached');
                        return resolution;
                    }
                    if ((this.session.debateRound ?? 0) >= (this.session.debateMaxRounds ?? 3)) {
                        this.transition('max_rounds');
                        break;
                    }
                    this.transition('no_consensus');
                    await this.runRebuttal(agreement.disputed);
                    this.transition('rebuttals_done');
                    break;
                }

                case 'RESOLVE': {
                    const resolution = await this.resolveFinalFindings();
                    if (this.session.debateState === 'tie_break') {
                        this.transition('tie_broken');
                    } else if (this.session.debateState === 'consensus_check') {
                        this.transition('consensus_reached');
                    }
                    return resolution;
                }

                case 'TIE_BREAK':
                    this.transition('max_rounds');
                    break;

                case 'START_REBUTTAL':
                    this.transition('no_consensus');
                    await this.runRebuttal(/** @type {FindingEntry[]} */ (action.payload.disputed ?? []));
                    this.transition('rebuttals_done');
                    break;

                case 'FAIL':
                    this.transition('error');
                    throw new Error(String(action.payload.reason ?? 'Debate failed'));

                case 'START_REVIEW':
                    throw new Error(`Unexpected action ${action.type} in executor loop`);

                default:
                    throw new Error(`Unhandled action ${action.type}`);
            }
        }

        throw new Error(`Debate terminated unexpectedly in state "${this.session.debateState}"`);
    }
}

export {
    buildInitialReviewPrompt,
    buildRebuttalPrompt,
    buildTieBreakPrompt,
};
